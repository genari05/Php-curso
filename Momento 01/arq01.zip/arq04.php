<?php

  //tipo objeto
/*
    class carro{

    	public $motor;

    	function ligar()
    	{
    		echo "Ligar o motor {$this->motor}";
    	}
    }
   
   $obj = new carro;
   $obj->motor = '2.0';
   $obj->ligar();
*/

  $a = 20;

 define("Sala", $a);
echo "Cada sala cabe no maximo " . Sala . " alunos";

