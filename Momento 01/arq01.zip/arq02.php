<?php

		//.php 
		//.class.php
		//.inc.inc

 #echo "Odair Gabriel";
 //echo "Odair Gabriel";

/*
 echo "Odair Gabriel 1 ";
 echo "Odair Gabriel 2 ";
echo "Odair Gabriel 3 ";
*/
echo 'Odair Gabriel 4' . "<br>";

print('Estou utilizando o comando print');

echo "<br>";
$vetor = array('Odair','Tatisa','Johann','Liam');
var_dump($vetor);

echo "<br>";
print_r($vetor);


?>
