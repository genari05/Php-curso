<?php

		//.php 
		//.class.php
		//.inc.inc

?>
