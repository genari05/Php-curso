<?php 

// ome_Aluno = 'Odair';

//	echo $nome_Aluno;

/*
	$x = 10;
	$y = &$x;
	$y = 50;


	echo $y;
	echo $x;



	$variavel = TRUE;

	if($variavel)
	{
		echo "variavel ok";
	}


$variavel1 = 1234567;
echo "Variavel Deciamal -> " . $variavel1 . "<br>";

$variavel2 = -12345;
echo "Variavel Negativo -> " . $variavel2 . "<br>";

$variavel3 = 12.345;
echo "Variavel Negativo -> " . $variavel3 . "<br>";

$variavel4 = 0x1A;
echo "Variavel Hexadecimal -> " . $variavel4 . "<br>";

$variavel_string1 = 'Odair Gabriel';
$variavel_string2 = "Johann Gabriel";

echo $variavel_string1 . "<br>";
echo $variavel_string2 . "<br>";
*/

$Lista = array('Odair','Tatisa','Johann','Liam');

echo $Lista[0] . "<br>"; 
echo $Lista[3] . "<br>";
echo $Lista[2] . "<br>";
echo $Lista[1]; 

































